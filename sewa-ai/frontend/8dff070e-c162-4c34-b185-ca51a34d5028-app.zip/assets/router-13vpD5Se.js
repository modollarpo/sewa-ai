import"./query-Dw3jgruK.js";import"./react-BWQDGYcZ.js";
//# sourceMappingURL=router-13vpD5Se.js.map
